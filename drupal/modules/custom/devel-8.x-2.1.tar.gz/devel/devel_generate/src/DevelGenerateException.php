<?php

namespace Drupal\devel_generate;

use Drupal\Component\Plugin\Exception;

/**
 * DevelGenerateException extending Generic Plugin exception class.
 */
class DevelGenerateException extends \Exception {

}
